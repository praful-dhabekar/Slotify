-- Adminer 4.6.2 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP DATABASE IF EXISTS `slotify`;
CREATE DATABASE `slotify` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `slotify`;

DROP TABLE IF EXISTS `albums`;
CREATE TABLE `albums` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(150) NOT NULL,
  `artist` int(11) NOT NULL,
  `genre` int(11) NOT NULL,
  `artwork` varchar(500) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `albums` (`id`, `title`, `artist`, `genre`, `artwork`) VALUES
(1,	'Bacon and Eggs',	2,	4,	'assets/images/artwork/clearday.jpg'),
(2,	'Pizza Head',	5,	3,	'assets/images/artwork/energy.jpg'),
(3,	'For You',	6,	2,	'assets\\images\\artwork\\forYou.jpg'),
(4,	'Life Changes\r\n',	10,	7,	'assets\\images\\artwork\\lifeChanges.jpg'),
(5,	'Purple Reign',	8,	4,	'assets\\images\\artwork\\purpleReign.jpg'),
(6,	'Faded',	13,	8,	'assets\\images\\artwork\\faded.png'),
(7,	'Revival',	6,	2,	'assets\\images\\artwork\\revival.jpg');

DROP TABLE IF EXISTS `artist`;
CREATE TABLE `artist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `artist` (`id`, `name`) VALUES
(1,	'Micky Mouse'),
(2,	'Goofy'),
(3,	'Bart Simpson'),
(4,	'Homer'),
(5,	'Luke Bryan'),
(6,	'Selena Gomez'),
(7,	'Sam Hunt'),
(8,	'Future'),
(9,	'Taylor Swift'),
(10,	'Thomas Rhett '),
(11,	'Cardi B'),
(12,	'Justin Timberlake '),
(13,	'Alan Walker '),
(14,	'Tobu');

DROP TABLE IF EXISTS `genre`;
CREATE TABLE `genre` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `genre` (`id`, `name`) VALUES
(1,	'Rock'),
(2,	'Pop'),
(3,	'Hip-hop'),
(4,	'Rap'),
(5,	'R & B'),
(6,	'Classical'),
(7,	'Country'),
(8,	'EDM'),
(9,	'Jazz'),
(10,	'Folk');

DROP TABLE IF EXISTS `songs`;
CREATE TABLE `songs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(250) NOT NULL,
  `artist` int(11) NOT NULL,
  `album` int(11) NOT NULL,
  `genre` int(11) NOT NULL,
  `duration` varchar(8) NOT NULL,
  `path` varchar(500) NOT NULL,
  `albumOrder` int(11) NOT NULL,
  `plays` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `songs` (`id`, `title`, `artist`, `album`, `genre`, `duration`, `path`, `albumOrder`, `plays`) VALUES
(1,	'Faded',	13,	6,	8,	'4:24',	'assets\\music\\Faded.mp3',	1,	0),
(5,	'The Heart Wants What It Wants',	6,	3,	2,	'3:47',	'assets\\music\\The Heart Wants What It Wants.mp3',	2,	0),
(6,	'Who Says',	6,	3,	2,	'3:15',	'assets\\music\\Who Says.mp3',	1,	0),
(7,	'Come & Get It',	6,	3,	2,	'3:51',	'assets\\music\\Come & Get It.mp3',	3,	0),
(8,	'Unforgettable',	10,	4,	7,	'2:37',	'assets\\music\\Unforgettable.m4a',	1,	0),
(9,	'Sweetheart',	10,	4,	7,	'3:26',	'assets\\music\\Sweetheart.m4a',	2,	0),
(10,	'Marry Me',	10,	4,	7,	'3:26',	'assets\\music\\Marry Me.m4a',	3,	0),
(11,	'Wicked',	8,	5,	4,	'2:53',	'assets\\music\\Wicked.mp3',	2,	0),
(12,	'Purple Reign Intro',	8,	5,	4,	'0:55',	'assets\\music\\Purple Reign Intro.mp3',	1,	0),
(13,	'Kill Em With Kindness',	6,	7,	2,	'3:40',	'assets\\music\\Kill Em With Kindness.mp3',	1,	0),
(14,	'Hands To Myself',	6,	7,	2,	'3:22',	'assets\\music\\Hands To Myself.mp3',	2,	0);

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(25) NOT NULL,
  `firstName` varchar(50) NOT NULL,
  `lastName` varchar(50) NOT NULL,
  `email` varchar(200) NOT NULL,
  `password` varchar(32) NOT NULL,
  `signUpDate` datetime NOT NULL,
  `profilePic` varchar(500) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `users` (`id`, `username`, `firstName`, `lastName`, `email`, `password`, `signUpDate`, `profilePic`) VALUES
(3,	'warbot',	'Praful',	'Dhabekar',	'Praful@github.io',	'd8578edf8458ce06fbc5bb76a58c5ca4',	'2018-04-02 10:47:36',	'assets/images/profile-pics/myAvatar.png'),
(4,	'prime',	'Optimus',	'Prime',	'Prime@cybertron.com',	'820c934dd79b60907f2bd499c0fb17ed',	'2018-04-02 10:49:54',	'assets/images/profile-pics/myAvatar.png');

-- 2018-04-04 16:18:30
